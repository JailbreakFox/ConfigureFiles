Source Code Pro for Powerline
=============================

:Font creator: Paul D. Hunt (Adobe)
:Version: 2.030
:Italics Version: 1.050
:Source: http://sourceforge.net/projects/sourcecodepro.adobe
:License: SIL OPEN FONT LICENSE Version 1.1
:Patched by: `Anwar <https://github.com/AnwarShah>`_


Source Code Pro is a set of monospaced OpenType fonts that have been
designed to work well in coding environments. This family of fonts is
a complementary design to the Source Sans family.

Source Code Pro for Powerline is derived from Source Code Pro font by Adobe
for Powerline users. The Powerline symbols is being made by Kim Silkebækken.
Initially only the regular variants were patched and was done by Carl X. Su.
The Italics were later added to the family and patched by Anwar. He also
repatched all the regular variants with updated version of the font.

Both the final font Truetype/OpenType files and the design files used
to produce the font family are distributed under an open licence and
you are expressly encouraged to experiment, modify, share and improve.
