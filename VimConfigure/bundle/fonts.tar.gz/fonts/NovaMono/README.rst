Nova Mono for Powerline
=====================================

:Font creator: Wojciech Kalinowski
:Source: https://fonts.google.com/specimen/Nova+Mono
:Patched by: `Anwar <https://github.com/AnwarShah>`_
